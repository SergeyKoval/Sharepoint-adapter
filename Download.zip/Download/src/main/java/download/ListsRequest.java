package download;

import java.util.HashMap;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

public class ListsRequest {

    private Document rootDocument;
    private Element rootDocContent;

    public ListsRequest(String requestType) throws Exception {
        if (requestType != null) {
            if (requestType.equals("New") || requestType.equals("Update") || requestType.equals("Delete")) {
                try {
                    Element rootElement = null;
                    DocumentBuilder docBuilder = null;
                    DocumentBuilderFactory dbfac = DocumentBuilderFactory.newInstance();
                    docBuilder = dbfac.newDocumentBuilder();
                    rootDocument = docBuilder.newDocument();

                    //Creates the root element
                    rootElement = rootDocument.createElement("Batch");
                    rootDocument.appendChild(rootElement);

                    //Creates the batch attributes
                    rootElement.setAttribute("ListVersion", "1");
                    rootElement.setAttribute("OnError", "Continue");
                    rootDocContent = rootDocument.createElement("Method");
                    rootDocContent.setAttribute("Cmd", requestType);
                    rootDocContent.setAttribute("ID", "1");
                    rootDocument.getElementsByTagName("Batch").item(0).appendChild(rootDocContent);
                } catch (ParserConfigurationException ex) {
                    ex.printStackTrace();
                    throw (new Exception(ex.toString()));
                }
            } else {
                String err = "Unsupported request type";
                throw (new Exception(err));
            }
        } else {
            String err = "Null parameters";
            throw (new Exception(err));
        }
    }

    public boolean createListItem(HashMap<String, String> fields) {
        //params check
        if (fields != null && getRootDocContent() != null && this.getRootDocument() != null && !fields.isEmpty()) {
            Element createdElement = null;
            //Adds attribute by attribute to fields
            for (Map.Entry<String, String> aField : fields.entrySet()) {
                createdElement = this.getRootDocument().createElement("Field");
                createdElement.setAttribute("Name", aField.getKey());
                Text attributeValue = getRootDocument().createTextNode("" + aField.getValue());
                createdElement.appendChild(attributeValue);
                this.getRootDocContent().appendChild(createdElement);
            }
            return true;
        }
        return false;
    }

    public Document getRootDocument() {
        return rootDocument;
    }

    public Element getRootDocContent() {
        return rootDocContent;
    }
}
