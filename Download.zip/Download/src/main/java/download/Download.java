package download;

import com.microsoft.schemas.sharepoint.soap.*;
import com.sun.org.apache.xerces.internal.dom.ElementNSImpl;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

public class Download {

    public static void main(String[] args) {
        try {

            //Authentication parameters
            String userName = "eltegra\\skoval";
            String password = "Bhbyf25ngl11";

            //Opening the SOAP port of the Lists Web Service
            ListsSoap port = sharePointListsAuth(userName, password);

        /*
         * Lists Web service parameters
         * The list names below must be the *original* names of the list.
         * if a list or column was renamed from SharePoint afterwards,
         * these parameters don't change.
         */
            String listName = "Test";
            String rowLimit = "150";
            ArrayList<String> listColumnNames = new ArrayList<String>();
            listColumnNames.add("LinkFilename");
            listColumnNames.add("FileRef");

            //Displays the lists items in the console
            displaySharePointList(port, listName, listColumnNames, rowLimit);




            // Download file
            CopySoap port1 = sharePointCopyAuth(userName, password);
            //downloadSharePointFile(port1, "http://localhost:12192/Test/FBA.mp4");
            //uploadSharePointFile(port1, "");
             /*
            <Field Name="ID">3</Field>
            <Field Name="FileRef">
                    http://Server/[sites/][Site/]Shared
            Documents/File</Field>         */

            HashMap<String, String> hmap = new HashMap<String, String>();
            hmap.put("ID", "1");
            hmap.put("FileRef", "1;#Test/FBA.mp4");

            deleteListItem(port, "Test", hmap);


        } catch (Exception ex) {
            System.err.println(ex);
        }
    }

    public static ListsSoap sharePointListsAuth(String userName, String password) throws Exception {
        ListsSoap port = null;
        if (userName != null && password != null) {
            try {
                Lists service = new Lists();
                port = service.getListsSoap();
                System.out.println("Web Service Auth Username: " + userName);
                ((BindingProvider) port).getRequestContext().put(BindingProvider.USERNAME_PROPERTY, userName);
                ((BindingProvider) port).getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, password);
            } catch (Exception e) {
                throw new Exception("Error: " + e.toString());
            }
        } else {
            throw new Exception("Couldn't authenticate: Invalid connection details given.");
        }
        return port;
    }

    public static CopySoap sharePointCopyAuth(String userName, String password) throws Exception {
        CopySoap port = null;

        if (userName != null && password != null) {
            try {
                Copy service = new Copy();
                port = service.getCopySoap();
                System.out.println("Web Service Auth Username: " + userName);
                ((BindingProvider) port).getRequestContext().put(BindingProvider.USERNAME_PROPERTY, userName);
                ((BindingProvider) port).getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, password);
            } catch (Exception e) {
                throw new Exception("Error: " + e.toString());
            }
        } else {
            throw new Exception("Couldn't authenticate: Invalid connection details given.");
        }
        return port;

    }

    public static void downloadSharePointFile(CopySoap port, String sourceURL) {
        Holder<Long> getItemResult = new Holder<Long>();
        getItemResult.value = new Long(20);

        Holder<FieldInformationCollection> fields = new Holder<FieldInformationCollection>();
        FieldInformationCollection fcol = new FieldInformationCollection();
        fcol.getFieldInformation().add(new FieldInformation());
        fields.value = fcol;

        Holder<byte[]> stream = new Holder<byte[]>();
        stream.value = new byte[] {};

        port.getItem(sourceURL, getItemResult, fields, stream);

        System.out.println(getItemResult.value + " " + stream.value.length);
    }

    public static void uploadSharePointFile(CopySoap port, String sourceURL1) throws Exception {
        try {
            String sourceURL = "file:///D:/46.jpg";
            File file = new File("D:/Test1.doc");
            BufferedInputStream inputStream = new BufferedInputStream(new FileInputStream(file));
            byte[] stream = new byte[inputStream.available()];
            inputStream.read(stream);

            DestinationUrlCollection destinationUrls = new DestinationUrlCollection();
            destinationUrls.getString().add("http://localhost:12192/Test/Test4.doc"); // попробовать без имени файла

            FieldInformationCollection infCollection = new FieldInformationCollection();

            FieldInformation fInf = new FieldInformation();
            fInf.setDisplayName(file.getName());
            fInf.setInternalName(file.getName());

            infCollection.getFieldInformation().add(fInf);

            Holder<Long> copyIntoItemsResult = new Holder<Long>();
            copyIntoItemsResult.value = new Long(0);

            Holder<CopyResultCollection> copyResultCollectionHolder = new Holder<CopyResultCollection>();
            copyResultCollectionHolder.value = new CopyResultCollection();
            copyResultCollectionHolder.value.getCopyResult().add(new CopyResult());

            port.copyIntoItems(sourceURL, destinationUrls, infCollection, stream, copyIntoItemsResult, copyResultCollectionHolder);

            String errorMessage = copyResultCollectionHolder.value.getCopyResult().get(0)
                    .getErrorMessage();

            System.out.println(errorMessage);
            // error message always exists
        } catch (FileNotFoundException ex) {
            System.out.println("FileNotFoundException : " + ex);
        } catch (IOException ioe) {
            System.out.println("IOException : " + ioe);
        } catch (Exception ex) {
            throw new Exception("Error: " + ex.toString());
        }
    }

    public static String xmlToString(Document docToString) {
        String returnString = "\n-------------- XML START --------------\n";
        try {
            //create string from xml tree
            //Output the XML
            //set up a transformer
            TransformerFactory transfac = TransformerFactory.newInstance();
            Transformer trans;
            trans = transfac.newTransformer();
            trans.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            trans.setOutputProperty(OutputKeys.INDENT, "yes");
            StringWriter sw = new StringWriter();
            StreamResult streamResult = new StreamResult(sw);
            DOMSource source = new DOMSource(docToString);
            trans.transform(source, streamResult);
            String xmlString = sw.toString();
            //print the XML
            returnString = returnString + xmlString;
        } catch (TransformerException ex) {
            ex.printStackTrace();
        }
        returnString = returnString + "-------------- XML END --------------";
        return returnString;
    }

    public static void displaySharePointList(ListsSoap port, String listName, ArrayList<String> listColumnNames, String rowLimit) throws Exception {
        if (port != null && listName != null && listColumnNames != null && rowLimit != null) {
            try {

                //Here are additional parameters that may be set
                String viewName = "";
                GetListItems.ViewFields viewFields = null;
                GetListItems.Query query = null;
                GetListItems.QueryOptions queryOptions = null;
                String webID = "";

                //Calling the List Web Service
                GetListItemsResponse.GetListItemsResult result = port.getListItems(listName, viewName, query, viewFields, rowLimit, queryOptions, webID);
                Object listResult = result.getContent().get(0);
                if ((listResult != null) && (listResult instanceof ElementNSImpl)) {
                    ElementNSImpl node = (ElementNSImpl) listResult;

                    //Dumps the retrieved info in the console
                    Document document = node.getOwnerDocument();
                    System.out.println(xmlToString(document));

                    //selects a list of nodes which have z:row elements
                    NodeList list = node.getElementsByTagName("z:row");
                    System.out.println("=> " + list.getLength() + " results from SharePoint Online");

                    //Displaying every result received from SharePoint, with its ID
                    for (int i = 0; i < list.getLength(); i++) {

                        //Gets the attributes of the current row/element
                        NamedNodeMap attributes = list.item(i).getAttributes();
                        System.out.println("******** Item ID: " + attributes.getNamedItem("ows_ID").getNodeValue()+" ********");

                        //Displays all the attributes of the list item that correspond to the column names given
                        for (String columnName : listColumnNames) {
                            String internalColumnName = "ows_" + columnName;
                            if (attributes.getNamedItem(internalColumnName) != null) {
                                System.out.println(columnName + ": " + attributes.getNamedItem(internalColumnName).getNodeValue());
                            } else {
                                throw new Exception("Couldn't find the '" + columnName + "' column in the '" + listName + "' list in SharePoint.\n");
                            }
                        }
                    }
                } else {
                    throw new Exception(listName + " list response from SharePoint is either null or corrupt\n");
                }
            } catch (Exception ex) {
                throw new Exception("Exception. See stacktrace." + ex.toString() + "\n");
            }
        }
    }

    public static void deleteListItem(ListsSoap port, String listName, HashMap<String, String> itemAttributes) {

        //Parameters validity check
        if (port != null && listName != null && itemAttributes != null && !itemAttributes.isEmpty()) {
            try {

                //Building the CAML query with one item to add, and printing request
                ListsRequest deleteRequest = new ListsRequest("Delete");
                deleteRequest.createListItem(itemAttributes);
                System.out.println("REQUEST:"
                        + xmlToString(deleteRequest.getRootDocument()));

                //initializing the Web Service operation here
                UpdateListItems.Updates updates = new UpdateListItems.Updates();

                //Preparing the request for the update
                Object docObj = (Object) deleteRequest.getRootDocument().getDocumentElement();
                updates.getContent().add(0, docObj);

                //Sending the insert request to the Lists.UpdateListItems Web Service
                UpdateListItemsResponse.UpdateListItemsResult result = port.updateListItems(listName, updates);

            /*
             *Printing the response in the console.
             *If successful, the inserted item will be returned
             */
                System.out.println("RESPONSE : "
                        + xmlToString((org.w3c.dom.Document) (((ElementNSImpl) result.getContent().get(0)).getOwnerDocument())));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
